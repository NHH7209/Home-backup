package com.example.modelexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModelExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModelExamApplication.class, args);
	}

}
